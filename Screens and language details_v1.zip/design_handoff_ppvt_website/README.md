# Handoff: पंच प्रण विकास ट्रस्ट (Panch Pran Vikas Trust) — Website

## Overview
Marketing and trust-building website for an Indian social-impact trust that works across five commitments (पंच प्रण): शिक्षा (Education), स्वावलंबन (Self-Reliance), पर्यावरण (Environment), महिला सशक्तिकरण (Women Empowerment), स्वास्थ्य (Health).

This handoff covers the **desktop homepage**, which establishes the full design system: brand lockup, colour tokens, type scale, section rhythm, card patterns, transparency treatment, donation module, and footer. All other pages in the sitemap (About, per-pillar pages, Projects, Impact, Story detail, Reports, Transparency, Donate, Volunteer, Partner, Contact, 404) should be built from these same components.

The design is deliberately Hindi-led with English support: Devanagari carries the headlines and brand voice, English carries the explanatory and international-facing copy.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes that show intended look, hierarchy, and behavior. They are **not production code to copy**.

The task is to **recreate these designs in the target codebase's own environment** (Next.js/React, Astro, Vue, plain templates — whatever the project uses) with its established patterns, component conventions, and build tooling. If no codebase exists yet, choose the framework appropriate for a content-driven, SEO-sensitive, performance-critical marketing site — a static or hybrid-static generator (Next.js App Router with static rendering, or Astro) is the natural fit, with content in a CMS or MDX so the trust can add programmes, projects, stories, and reports without a deploy.

Notably, the prototype uses a custom `<image-slot>` element as a drag-and-drop photo placeholder. **Do not port that.** Replace every slot with the real responsive image component of the target stack (`next/image`, Astro `<Image>`, etc.) fed from the CMS.

## Fidelity
**High-fidelity.** Colours, type sizes, weights, spacing, and states are final and should be matched closely. Two caveats:

- **Photography is unresolved.** Every image is a labelled placeholder with art direction written into the placeholder text. Build the layout so real documentary photography drops in at the stated aspect ratios.
- **All numbers, registration details, locations, and documents are labelled placeholders.** The design intentionally shows them as unverified, in monospace annotations. The organisation has not supplied verified data. Do not ship any figure, registration number, certification, partner logo, or impact statistic as fact. See "Placeholder and data-integrity rules" below — this is a hard requirement of the brief, not a styling note.

## Screens / Views

### Homepage
Single narrative scroll, max content width **1440px**, centred, horizontal page padding **56px**. Background `#FAF8F3`.

Section order (each with a monospace eyebrow numbering the chapter):
1. Sticky header
2. Hero
3. Trust strip
4. `01 — Our commitments` — Panch Pran (five cards)
5. `02 — Our approach` — five-step journey
6. `03 — Impact` — five metrics on sand background
7. `04 — Stories of change` — editorial, one lead + two secondary
8. `05 — Initiatives` — three project cards
9. `06 — Transparency` — dark green section
10. `07 — Get involved` — five cards
11. Donation module
12. Footer

---

#### 1. Sticky header
- `position: sticky; top: 0; z-index: 50`. Padding `16px 56px`. Background `rgba(250,248,243,.92)` with `backdrop-filter: blur(10px)`. Bottom border `1px solid #E9DDC8`.
- Layout: `flex`, `space-between`, `gap: 32px` — brand lockup / nav / utilities.
- **Brand lockup**: emblem image 56×56, `object-fit: contain`, `gap: 14px` to a two-line stack: Devanagari name at 19px/600/1.25, `letter-spacing: -.01em`, colour `#17211D`; below it `PANCH PRAN VIKAS TRUST` at 10.5px/500, `letter-spacing: .16em`, uppercase, `#5F6964`.
- **Nav**: `flex`, `gap: 30px`, 14.5px/500. Items: Home, About Us, Our Work, Impact, Get Involved, Resources, Contact. Active item is `#174A3A` with a `2px` bottom border in the same colour and `padding-bottom: 2px`. In production each of these needs a dropdown or mega-menu — the sitemap below lists the children; the prototype shows only the top level.
- **Language switcher**: `हिन्दी` (13px/600, `#174A3A`) · 1×14px divider `#CFC6B2` · `English` (13px/500, `#5F6964`). Active locale is the coloured, heavier one.
- **Header CTA**: pill, `padding: 11px 20px`, `border-radius: 999px`, background `#174A3A`, text `#FAF8F3` 14px/600, label `सहयोग करें`. Hover background `#0F3629`.

#### 2. Hero
- Full-width block inside page padding, `height: 640px`, `border-radius: 4px`, `overflow: hidden`, `margin-top: 20px`.
- Background: full-bleed documentary photograph. Art direction: *community learning or livelihood activity, natural morning light, landscape crop.* Dignity over pity — people as participants and creators, never as subjects of suffering.
- Scrim above the image, `pointer-events: none`: `linear-gradient(100deg, rgba(15,32,25,.82) 0%, rgba(15,32,25,.55) 46%, rgba(15,32,25,.05) 78%)`.
- Content block: absolutely positioned left, vertically centred, `max-width: 720px`, `padding: 0 60px`, `gap: 28px`.
  - Eyebrow: 26×1px rule in `#D97745`, then `पंच प्रण · एक संकल्प · सतत विकास` at 11.5px/600, `letter-spacing: .18em`, uppercase, `#E9DDC8`.
  - `<h1>` Devanagari, **66px/600**, `line-height: 1.16`, `letter-spacing: -.02em`, `#FAF8F3`, three lines: `पंच प्रण।` / `एक संकल्प।` / `बेहतर भविष्य।`
  - Sub: English, 18.5px/1.6, `rgba(250,248,243,.86)`, `max-width: 520px` — "Five commitments. One shared vision for a stronger, healthier and self-reliant India."
  - CTAs, `gap: 14px`: primary pill `padding: 15px 26px`, background `#D97745`, text `#17211D` 16px/600, label `हमारे कार्य देखें`, hover `#E88A58`. Secondary pill, same padding, `1px solid rgba(250,248,243,.5)`, text `#FAF8F3`, label `हमसे जुड़ें`, hover background `rgba(250,248,243,.12)`.
- Scroll indicator, bottom-right (`right: 34px; bottom: 30px`): vertical monospace `scroll` at 10px, `letter-spacing: .16em`, `writing-mode: vertical-rl`, `rgba(250,248,243,.7)`; below it a 1×38px gradient bar fading to transparent, animated with the `nudge` keyframes (see Motion).

#### 3. Trust strip
Directly under the hero, `padding: 26px 4px 0`, `flex-wrap`, `gap: 40px`, 13px `#5F6964`. Each item: 7px `#6F927F` dot + label. Three items:
- "Registered public charitable trust" followed by a monospace 11px `#8A9490` annotation `[registration no. — to be provided]`
- "Annual reports published publicly"
- "Community-led programmes across five focus areas"

#### 4. Panch Pran
- Section padding `120px 56px 0`.
- Header row: `flex-wrap`, `space-between`, `gap: 40px`, `padding-bottom: 56px`, bottom border `1px solid #E9DDC8`.
  - Left: monospace eyebrow `01 — OUR COMMITMENTS` (11px, `.18em`, `#D97745`); `<h2>` Devanagari 46px/600, `line-height: 1.2`, `letter-spacing: -.02em` — `हमारे पाँच प्रण`.
  - Right: Devanagari 17px/1.75 `#5F6964`, `max-width: 520px` — `हमारा विश्वास है कि स्थायी विकास तभी संभव है जब शिक्षा, स्वावलंबन, पर्यावरण, महिला सशक्तिकरण और स्वास्थ्य साथ-साथ आगे बढ़ें।`
- Card row: `grid-template-columns: repeat(5, 1fr)`, `gap: 1px` with the grid background `#E9DDC8` — the gap **is** the hairline rule between cards. Bottom border `1px solid #E9DDC8`. Cards carry no border or radius of their own; the system reads as one connected band rather than five detached boxes. This is intentional and central to the design.
- Each card: `padding: 36px 28px 32px`, background `#FAF8F3`, hover background `#F3F0E7`, `gap: 20px`, column flex.
  - Top row: monospace index (`01`–`05`, 12px, `#8A9490`) and a 36×36 geometric symbol on the right.
  - Title block: Devanagari `<h3>` 25px/600/1.3; English label 12px/600, `.12em`, uppercase, `#6F927F`.
  - Body: 14.5px/1.7 `#5F6964`, `flex: 1` so links bottom-align.
  - Link: Devanagari 14px/600 `#174A3A` — `जानें अधिक →`.
- **Symbols** — one visual per pillar, all built from squares, circles, and diamonds at 1.5px stroke, `#174A3A` primary with a `#D97745` or `#6F927F` accent detail. In production, replace with a proper icon set drawn by a designer, keeping the same restraint: single-weight line work, one accent per glyph, no illustration, no emoji.
  1. **शिक्षा** — 3px-radius square, two horizontal rules inside (an open book/page): 20px `#174A3A`, 12px `#D97745`.
  2. **स्वावलंबन** — circle, 6px `#D97745` centre dot, 1.5×12px stem rising out of the top.
  3. **पर्यावरण** — 26px square rotated 45°, 6px `#6F927F` diamond at centre.
  4. **महिला सशक्तिकरण** — 36px circle with a concentric 18px `#D97745` circle.
  5. **स्वास्थ्य** — 3px-radius square with a `#D97745` cross (two 1.5px bars, 20px each).

Copy for the five cards:
| # | Hindi | English | Body |
|---|---|---|---|
| 01 | शिक्षा | Education | Access to quality education, learning opportunities and skills for children and communities. |
| 02 | स्वावलंबन | Self-Reliance | Economic independence through skills, livelihoods, enterprise and vocational development. |
| 03 | पर्यावरण | Environment | Conservation, plantation, water protection, waste management and responsible living. |
| 04 | महिला सशक्तिकरण | Women Empowerment | Skills, economic independence, leadership and participation in community decisions. |
| 05 | स्वास्थ्य | Health | Preventive health awareness, nutrition, sanitation and community health outreach. |

#### 5. Our approach
- Section padding `120px 56px`.
- Header: monospace eyebrow `02 — OUR APPROACH`; `<h2>` English 40px/600, `line-height: 1.22`, `letter-spacing: -.02em`, `max-width: 640px` — "We work with communities, not simply for them."
- Timeline, `margin-top: 72px`: a 1px `#E9DDC8` horizontal rule absolutely positioned at `top: 7px` spanning the full width, with a `repeat(5, 1fr)` grid (`gap: 32px`) sitting on top.
- Each step: a 15px dot (`border-radius: 50%`, `border: 3px solid #FAF8F3`, `box-shadow: 0 0 0 1px <dot colour>`) so the dot punches through the rule; then Devanagari `<h3>` 24px/600, an English 11.5px/600 `.12em` uppercase `#6F927F` label, and a 14.5px/1.7 `#5F6964` line. `gap: 18px`.
- Step 3 (`साथ चलना`) uses the terracotta dot `#D97745`; the other four use `#174A3A`. That single accent marks the pivot of the method — the design's one deliberate asymmetry in this section.

Steps:
| Hindi | English | Body |
|---|---|---|
| सुनना | Listen | We begin by listening to the people who live with the problem. |
| समझना | Understand | Local needs are studied before any programme is designed. |
| साथ चलना | Walk together | Programmes are run alongside communities, sharing decisions. |
| सक्षम बनाना | Enable | The goal is long-term capability, not short-term relief. |
| स्थायी बदलाव | Measure change | Outcomes are recorded, reviewed and published openly. |

#### 6. Impact
- Full-bleed band, background `#E9DDC8`, padding `110px 56px`.
- Header row: `space-between`, `flex-wrap`, `gap: 40px`. Left: monospace eyebrow `03 — IMPACT` in `#8A5A34` (the darkened terracotta used for eyebrows on sand, for contrast); `<h2>` Devanagari 42px/600 — `हमारे प्रभाव की कहानी`. Right: outline pill, `padding: 14px 24px`, `1px solid #174A3A`, text `#174A3A` 15px/600 — "View the full impact report →", hover inverts to `#174A3A` background with `#FAF8F3` text.
- Metric row, `margin-top: 64px`: `repeat(5, 1fr)`, `gap: 1px` over a `rgba(23,74,58,.18)` background (same hairline-via-gap technique). Each cell `padding: 34px 24px`, background `#E9DDC8`, `gap: 10px`:
  - Number: 56px/600, `letter-spacing: -.03em`, `line-height: 1`, `#174A3A`
  - Label: 14px/600 `#17211D`
  - Annotation: monospace 10.5px `#8A5A34` — `placeholder — awaiting verified figure`
- Placeholder metrics (layout only): `10,000+` Lives reached · `2,500+` Students supported · `1,000+` Women in livelihood programmes · `50+` Community initiatives · `25+` Villages & communities.
- Disclaimer block below, `margin-top: 34px`, `padding: 18px 22px`, background `rgba(250,248,243,.6)`, `border-left: 2px solid #D97745`, body 13.5px/1.7 `#5F6964`, `max-width: 900px`: "Every figure above is a layout placeholder. The interface is built so verified numbers, the year they cover, and the source report can be inserted per metric once the trust provides them."
- **Data model note:** each metric needs `value`, `label`, `periodCovered`, and `sourceDocument`. The UI must be able to render provenance next to the number once it exists, and must render the placeholder annotation whenever `value` is unverified.

#### 7. Stories of change
- Section padding `120px 56px`. Header: monospace eyebrow `04 — STORIES OF CHANGE`; `<h2>` Devanagari 42px/600 — `बदलाव की कहानियाँ`; `margin-bottom: 56px`.
- Body grid: `grid-template-columns: 1.35fr 1fr`, `gap: 56px`, `align-items: start`.
- **Lead story** (left): image 460px tall, `border-radius: 4px`, `overflow: hidden`. Art direction: *woman at her workplace, environmental context, natural light, 4:3.* Below it, `gap: 16px`, `max-width: 640px`:
  - Meta row: pillar chip — Devanagari 13px, `padding: 5px 12px`, `border-radius: 999px`, background `#E9DDC8`, text `#17211D` — plus location in 12px/600 `.1em` uppercase `#6F927F`.
  - `<h3>` Devanagari 34px/600/1.3, `letter-spacing: -.01em` — `सीमा की कहानी`
  - Body Devanagari 17px/1.8 `#5F6964`.
  - Monospace 11.5px `#8A9490` note: "Placeholder narrative — replace with interview-based story, consent recorded, outcome verified."
  - Link Devanagari 15px/600 `#174A3A` — `पूरी कहानी पढ़ें →`
- **Secondary stories** (right column, `gap: 36px`): image 210px tall, then meta chip + location (chip 12.5px, `padding: 4px 10px`), `<h3>` English 21px/600/1.35, body 14.5px/1.7 `#5F6964`.
- Story schema for the CMS, matching the editorial intent: person, location, pillar, challenge, intervention, transformation, measurable outcome, consent flag, photographer credit.

#### 8. Featured initiatives
- Section padding `0 56px 120px`. Header row `space-between` with `padding-bottom: 36px` and a `1px solid #E9DDC8` bottom rule: monospace eyebrow `05 — INITIATIVES`, `<h2>` English 36px/600 "Featured initiatives", and an "All projects →" link at 15px/600 `#174A3A`.
- Grid `repeat(3, 1fr)`, `gap: 28px`, `margin-top: 40px`.
- Card: `1px solid #E9DDC8`, `border-radius: 4px`, `overflow: hidden`, background `#FFFDF8`, hover border `#6F927F`. (These cards *do* have borders — unlike the Panch Pran band, which is a connected system. Keep the distinction.)
  - Image area 200px tall.
  - Body `padding: 24px 24px 26px`, `gap: 14px`, `flex: 1`.
  - Meta row: pillar chip (as above) + status. Status = 6px dot + 11.5px/600 `.08em` uppercase label. Active → `#6F927F` dot, `#174A3A` text. Planned → `#D97745` dot, `#5F6964` text. **Status is never colour-only** — the word is always present, per the accessibility rules.
  - `<h3>` 21px/600/1.35; body 14.5px/1.7 `#5F6964`, `flex: 1`.
  - Footer row: `padding-top: 14px`, `border-top: 1px solid #EFEADF`, `space-between` — location 13px `#5F6964` and `प्रोजेक्ट देखें →` at 14px/600 `#174A3A`.
- Placeholder cards: *Community Learning Initiative* (शिक्षा, Active, Uttar Pradesh) · *Livelihood Collectives* (महिला सशक्तिकरण, Active, "Location — to be confirmed") · *Preventive Health Outreach* (स्वास्थ्य, Planned, "Location — to be confirmed").

#### 9. Transparency
- Full-bleed band, background `#174A3A`, text `#FAF8F3`, padding `110px 56px`.
- Grid `1fr 1.15fr`, `gap: 80px`, `align-items: start`.
- Left column, `gap: 22px`: monospace eyebrow `06 — TRANSPARENCY` in `#D97745`; `<h2>` Devanagari 42px/600, `line-height: 1.24` — `आपका विश्वास, हमारी जिम्मेदारी`; body 16.5px/1.75 `rgba(250,248,243,.75)`, `max-width: 420px` — "Governance documents, audited accounts and programme reports are published as they are approved. Nothing is shown here until it exists."; then a light pill CTA (`background: #FAF8F3`, text `#174A3A`, `padding: 14px 24px`, hover `#E9DDC8`) — "Transparency centre →".
- Right column: `1fr 1fr` grid, `gap: 1px` over `rgba(250,248,243,.16)`; each cell `padding: 26px`, background `#174A3A`, with a 14.5px/600 title and a monospace 11px `rgba(250,248,243,.55)` status line. Six cells: Annual reports (*awaiting upload*), Audited financial statements (*awaiting upload*), Registration details (*to be provided by the trust*), Governing body & leadership (*to be provided by the trust*), Policies & compliance (*awaiting upload*), Donor information & use of funds (*awaiting upload*).
- Once documents exist, each cell becomes a link to a dated PDF with file size and publication date; the empty state above is the honest default, not a placeholder to be quietly filled with claims.

#### 10. Get involved
- Section padding `120px 56px 0`. Header: monospace eyebrow `07 — GET INVOLVED`; `<h2>` Devanagari 42px/600 — `साथ मिलकर बदलाव लाएँ`; `margin-bottom: 52px`.
- Grid `repeat(5, 1fr)`, `gap: 20px`. Each card is an anchor: `padding: 28px 24px 26px`, `1px solid #E9DDC8`, `border-radius: 4px`, background `#FFFDF8`, hover border `#174A3A`, `gap: 12px`; monospace index 11px `#8A9490`, title 19px/600 `#17211D`, body 14px/1.7 `#5F6964`.
- Cards: **Donate** "Support programmes financially, once or monthly." · **Volunteer** "Give time and skills to a programme near you." · **Partner** "Collaborate with us on shared objectives." · **Advocate** "Help more people learn about this work." · **Corporate CSR** "Build long-term social-impact initiatives."

#### 11. Donation module
- Section padding `110px 56px`. Inner panel: `padding: 56px`, background `#E9DDC8`, `border-radius: 4px`, grid `1fr 0.9fr`, `gap: 72px`, `align-items: center`.
- Left, `gap: 20px`: `<h2>` Devanagari 36px/600/1.3 — `आपका सहयोग, समुदाय की दिशा`; body Devanagari 17px/1.8 `#4C5651`, `max-width: 520px` — `आपका योगदान शिक्षा, स्वास्थ्य, स्वावलंबन, पर्यावरण और महिला सशक्तिकरण के प्रयासों को आगे बढ़ाने में मदद करता है।`; monospace 11.5px `#8A5A34` note — "Payment gateway, receipting and tax-exemption details will appear here once the trust's compliance information is confirmed."
- Right, the form card: `padding: 32px`, background `#FAF8F3`, `border-radius: 4px`, `gap: 18px`.
  - Frequency toggle: `padding: 5px` track, background `#EFEADF`, `border-radius: 999px`, two equal segments at `padding: 9px`, 13.5px/600. Selected = `#174A3A` background, `#FAF8F3` text. Options: One-time / Monthly.
  - Amount row: `repeat(3, 1fr)`, `gap: 10px`. Chips `padding: 14px 0`, `border-radius: 3px`, 15px/600, `1px solid #DED6C4`; selected chip `1.5px solid #174A3A` with `#174A3A` text. Values ₹500 / ₹1,000 / ₹2,500. Production needs a fourth "Other amount" input.
  - Directed-giving block: 12.5px/600 `#5F6964` label "Direct your contribution (optional)" and five Devanagari 13px pill chips (`padding: 6px 12px`, `1px solid #DED6C4`) for the five pillars.
  - Submit: full-width pill, `padding: 15px`, background `#D97745`, text `#17211D` 16px/600 — `सहयोग करें`, hover `#E88A58`.
  - Reassurance line, centred, 12px `#5F6964`: "Secure payment · Receipt by email · Donor details never published".
- **Tone rule:** invite, never pressure. No countdown timers, no guilt copy, no "₹500 educates a child for a month" style claims unless the trust has verified data behind the exact figure.

#### 12. Footer
- Background `#17211D`, text `rgba(250,248,243,.72)`, padding `80px 56px 32px`.
- Top grid `1.3fr repeat(4, 1fr)`, `gap: 48px`, `padding-bottom: 56px`, bottom border `1px solid rgba(250,248,243,.14)`.
- Brand column: emblem 88×88; Devanagari name 21px/600 `#FAF8F3`; English name 11px/500 `.16em` uppercase `rgba(250,248,243,.5)`; address block 14px/1.75 (registered office / email / phone — all "to be provided"); social row 12.5px/600 with `·` separators (Instagram, LinkedIn, YouTube).
- Four link columns, each with an 11.5px/600 `.14em` uppercase `#FAF8F3` heading and 14px links (`gap: 14px`):
  - **Organization** — About, Vision & Mission, Panch Pran, Leadership
  - **Programmes** — the five pillars in Devanagari at 14.5px
  - **Get involved** — Donate, Volunteer, Partner, Contact
  - **Transparency** — Annual reports, Financial information, Governance, Policies
- Legal bar: `padding-top: 26px`, `space-between`, 12.5px `rgba(250,248,243,.5)` — "© Panch Pran Vikas Trust" and Privacy Policy / Terms of Use / Cookie Policy / Accessibility (`gap: 22px`).

---

## Sitemap to build out
Header nav needs dropdowns for these; the prototype shows top level only.

- **Home**
- **About Us** — Our Story · Vision & Mission · Panch Pran · Leadership · Governance · Our Approach
- **Our Work** — शिक्षा · स्वावलंबन · पर्यावरण · महिला सशक्तिकरण · स्वास्थ्य (one templated pillar page, five instances)
- **Impact** — Our Impact · Stories of Change · Projects · Impact Numbers · Reports & Publications
- **Get Involved** — Donate · Volunteer · Partner With Us · Corporate Partnerships · Become a Supporter
- **Resources** — Annual Reports · Financial Transparency · News & Updates · Media · Documents
- **Contact**
- Plus a 404 page.

## Interactions & Behavior
- **Nav**: sticky header, translucent with blur; active section indicated by the underline. Anchor links in the prototype stand in for real routes.
- **Hover states** (all `~150ms ease` on colour/background/border only — never on layout properties):
  - Pillar cards: background `#FAF8F3` → `#F3F0E7`
  - Initiative and Get-involved cards: border `#E9DDC8` → `#6F927F` / `#174A3A`
  - Primary buttons: `#174A3A` → `#0F3629`; terracotta `#D97745` → `#E88A58`
  - Ghost/outline buttons: fill with their border colour, text inverts
  - All links: `#174A3A` → `#D97745`
- **Scroll reveal**: sections fade up ~16px on entry, staggered ~60ms within a row, `ease-out`, ~400ms. Once only; never re-animates on scroll-back.
- **Impact count-up**: numbers count from 0 on first entry into the viewport, ~1.2s, ease-out. Must be skipped entirely under `prefers-reduced-motion`, showing the final value immediately.
- **Hero**: a very slow scale (1.0 → 1.04 over ~20s) on the photograph is the intended ambient motion. No parallax.
- **Scroll indicator**: `nudge` keyframes — `translateY(0)` at 0/100% with `opacity: .55`, `translateY(7px)` with `opacity: 1` at 50%, `2.4s ease-in-out infinite`.
- **Donation form**: frequency toggle and amount chips are single-select; selecting a preset clears a custom amount and vice versa. Pillar chips are multi-select and optional. Validate amount before enabling submit; show inline field errors, never a modal alert.
- **Language switcher**: swaps locale and stays on the equivalent route. Both locales share one layout — the design must absorb length differences (English runs 15–30% longer in most labels) without a separate template. Set `lang` on `<html>` correctly for each locale so Devanagari shaping and screen-reader pronunciation are right.

## Responsive behavior
The prototype is desktop-only. Mobile is not a shrink of it — design intent per breakpoint:

- **≥1280px** — as documented.
- **1024–1279px** — page padding to 40px; Panch Pran and Impact rows to 3 columns (hairline-gap technique holds); Get-involved to 3 columns; Stories grid to `1.2fr 1fr`; hero height 560px, `<h1>` 52px.
- **768–1023px** — Stories stack to one column; Initiatives to 2 columns; Approach timeline becomes a vertical rail (dots on a left-hand vertical line, content to the right); hero `<h1>` 44px.
- **<768px** — page padding 20px; every grid to a single column; Panch Pran becomes a vertical stack with 1px `#E9DDC8` dividers between rows (keeping the connected-system reading); Impact metrics 2-up with numbers at 40px; hero height ~520px with the scrim shifted to a vertical `linear-gradient` so the headline stays legible, `<h1>` 34–38px; header collapses to emblem + hamburger with the language switcher inside the drawer; a persistent bottom bar carries `सहयोग करें`.
- **Mobile nav drawer**: full-height overlay, sections expandable, tap targets ≥44px, language switcher and donate CTA pinned at the bottom, focus trapped while open, Escape and backdrop tap both close, body scroll locked.

## State Management
Nearly all content is static/CMS-driven. Client state is confined to:
- `mobileNavOpen: boolean`
- `expandedNavSection: string | null`
- `locale: 'hi' | 'en'` — persisted, and reflected in the URL (`/hi/...`, `/en/...`) so pages are indexable per language
- Donation form: `frequency`, `amount`, `customAmount`, `directedPillars: string[]`, `donor` fields, `validationErrors`, `submitState: idle | submitting | error | success`
- `hasCountedUp: boolean` per impact metric (so count-up runs once)
- Forms needing a backend: donation, volunteer signup, partner enquiry, contact, newsletter. All need server-side validation and spam protection (a privacy-respecting challenge, not a tracking-heavy one).

Data fetching: content at build time where possible (programmes, projects, stories, reports, impact metrics). Donation is the only genuinely dynamic path — hand it to a PCI-compliant gateway; never touch card data in your own code.

## Design Tokens

### Colour
| Token | Value | Use |
|---|---|---|
| `primary` | `#174A3A` | Deep forest green — brand, headings on light, primary buttons, transparency band |
| `primary-hover` | `#0F3629` | Primary button hover |
| `secondary` | `#D97745` | Terracotta — hero CTA, eyebrows, accents |
| `secondary-hover` | `#E88A58` | Terracotta hover |
| `secondary-on-sand` | `#8A5A34` | Darkened terracotta for text on `#E9DDC8` (contrast) |
| `accent` | `#6F927F` | Muted green — English pillar labels, status dots, hover borders |
| `sand` | `#E9DDC8` | Section band, chips, hairline rules |
| `background` | `#FAF8F3` | Warm ivory page background |
| `surface` | `#FFFDF8` | Card surface, one step lighter than the page |
| `surface-alt` | `#F3F0E7` | Pillar card hover |
| `track` | `#EFEADF` | Toggle track, card inner divider |
| `border` | `#E9DDC8` | Standard border/hairline |
| `border-strong` | `#DED6C4` | Form field borders |
| `border-divider` | `#CFC6B2` | Language switcher divider |
| `text` | `#17211D` | Charcoal body/heading |
| `text-muted` | `#5F6964` | Secondary text |
| `text-muted-dark` | `#4C5651` | Body on sand |
| `text-faint` | `#8A9490` | Monospace annotations, indices |
| `on-dark` | `#FAF8F3` | Text on green/charcoal |
| `on-dark-muted` | `rgba(250,248,243,.72)` | Footer body |
| `on-dark-faint` | `rgba(250,248,243,.5)` | Footer legal |
| `scrim` | `rgba(15,32,25,.05 → .82)` | Hero gradient stops |

Semantic tokens still to define (not exercised on the homepage): `success` (derive from `#6F927F`), `warning` (derive from `#D97745`), `error` (a desaturated brick that sits with the palette — not a stock red), and `focus`. Every one must clear WCAG AA against both `#FAF8F3` and `#FFFDF8`.

### Typography
- **English / Latin**: Plus Jakarta Sans — 400, 500, 600, 700
- **Hindi / Devanagari**: Noto Sans Devanagari — 400, 500, 600, 700
- **Mono**: IBM Plex Mono — 400, 500. Used *only* for eyebrows, indices, and placeholder annotations. That is what makes provisional data legible as provisional; keep the convention.

Scale as used:
| Level | Size / weight / leading |
|---|---|
| Hero display (hi) | 66 / 600 / 1.16, `-.02em` |
| H2 section (hi) | 42–46 / 600 / 1.2–1.24, `-.02em` |
| H2 section (en) | 36–40 / 600 / 1.22, `-.02em` |
| H3 story lead (hi) | 34 / 600 / 1.3, `-.01em` |
| H3 pillar (hi) | 25 / 600 / 1.3 |
| H3 approach (hi) | 24 / 600 |
| H3 card (en) | 21 / 600 / 1.35 |
| Body large | 17–18.5 / 400 / 1.6–1.8 |
| Body | 14.5–15 / 400 / 1.7 |
| Body small | 13–14 / 400 / 1.7 |
| Caption | 12–12.5 / 400–600 |
| Eyebrow (mono) | 11 / 500, `.18em`, uppercase |
| Annotation (mono) | 10.5–11.5 / 400 |
| Button | 14–16 / 600 |
| Nav | 14.5 / 500 |

Devanagari runs optically smaller at the same px and needs more leading; where Hindi and English sit adjacent, the Devanagari is set 1–2px larger (see the footer programmes column at 14.5 against 14). Preserve that. Never substitute a decorative Devanagari face.

### Spacing
8px base scale: 4, 8, 12, 16, 20, 24, 28, 32, 40, 48, 56, 72, 80, 110, 120. Section vertical rhythm is 110–120px desktop; page gutter 56px.

### Radius
`3px` (form chips) · `4px` (cards, images, panels — the house radius) · `999px` (pills) · `50%` (dots, circular symbols). Nothing softer; the design reads crisp, not rounded.

### Shadow
Effectively none. The only `box-shadow` is structural — `0 0 0 1px <colour>` rings on the timeline dots. Depth comes from the ivory/`#FFFDF8` surface step and hairline borders. **Do not add drop shadows.**

### Hairline-via-gap pattern
Used in three places (Panch Pran, Impact metrics, Transparency grid): set the grid's own `background` to the rule colour and `gap: 1px`, then give each child an opaque background. Reusable as a `<HairlineGrid>` primitive.

## Accessibility (WCAG 2.2 AA — required, not optional)
- Semantic HTML: one `<h1>` per page, ordered headings, `<nav>` / `<main>` / `<section>` / `<footer>`, `<article>` for cards.
- All text clears AA. Two to re-check in code because they are close: 14px `#5F6964` on `#FAF8F3`, and terracotta `#D97745` used as text — which is why `#8A5A34` exists for text on sand. Terracotta on charcoal button text (`#17211D` on `#D97745`) is deliberate; do not flip it to white.
- Visible focus on every interactive element: 2px `#174A3A` outline with 2px offset on light, `#FAF8F3` on dark. Never `outline: none`.
- Full keyboard operability, logical tab order, skip-to-content link, focus trap and restoration in the mobile drawer.
- No colour-only communication: project status always pairs the dot with a word; the active locale is weight + colour, not colour alone.
- `alt` text on every photograph, written as description not keywords; decorative shapes get `aria-hidden`.
- Honour `prefers-reduced-motion: reduce` — the prototype disables all animation and transition under it. Count-ups jump to final value.
- Forms: real `<label>` elements, errors announced and tied via `aria-describedby`, no placeholder-as-label.
- Devanagari needs adequate size and leading to stay readable — do not go below 14px for Hindi body text.

## Placeholder and data-integrity rules
This is the load-bearing constraint of the brief. Carry it into the implementation:

- Never render fabricated registration numbers, certifications, awards, partner logos, donor logos, or impact statistics.
- Where data is missing, show a clearly marked placeholder in IBM Plex Mono (the existing convention) rather than a plausible-looking value.
- Make the impact and transparency components render an honest empty state by default, so an unpopulated CMS field can never read as a claim.
- Impact metrics carry provenance (`periodCovered`, `sourceDocument`) alongside the number.
- No unverified giving claims ("₹500 educates a child for a month") anywhere in donation copy.
- Stories require recorded consent from the subject and a photographer credit before publication.

## Photography direction
Authentic documentary photography, natural light, Indian rural and semi-urban contexts, real environments and clothing, intergenerational range. People shown as participants, learners, entrepreneurs and leaders. **Dignity over pity** — no staged NGO tableaux, no poverty spectacle, no Western stock, no artificially perfect smiling groups.

Slots and intended crops:
| Slot | Subject | Crop |
|---|---|---|
| Hero | Community learning or livelihood activity, morning light | wide landscape, ~2.25:1 |
| Lead story | Woman at her workplace, environmental context | ~4:3, 460px tall |
| Story 2 | Children in a learning space | ~16:9, 210px tall |
| Story 3 | Plantation or water conservation work | ~16:9, 210px tall |
| Project 1 | Learning centre | ~16:9, 200px tall |
| Project 2 | Women's livelihood group | ~16:9, 200px tall |
| Project 3 | Health camp | ~16:9, 200px tall |

Serve AVIF/WebP with responsive `srcset`, LQIP or dominant-colour placeholders, `loading="lazy"` below the fold, and an explicit priority hint on the hero.

## SEO
- Per-locale routes (`/hi/`, `/en/`) with `hreflang` pairs and self-referencing canonicals; descriptive slugs.
- `Organization` / `NGO` structured data with name in both scripts, logo, contact, and social profiles. `Article` for stories, `Project` or `Event` where apt. Only include fields that hold verified data.
- Unique title and meta description per page; Open Graph and Twitter cards using real photography, with the emblem as fallback.
- `sitemap.xml`, `robots.txt`. Semantic headings carry the keyword work — no stuffing.
- Target terms: Panch Pran Vikas Trust, पंच प्रण विकास ट्रस्ट, education NGO, women empowerment, rural development, environmental initiatives, healthcare initiatives, livelihood development.

## Performance (target Lighthouse 90+ on mid-range Android, 4G)
- Static render the content pages; ship minimal JS (nav drawer, count-up, form — nothing else needs hydration).
- Self-host the three font families, subset Latin and Devanagari separately, `font-display: swap`, preload only the two faces used above the fold. Devanagari subsets are heavy — this is the single biggest budget item.
- Compress and size all photography properly; the hero is the LCP element and needs an explicit width/height to avoid CLS.
- Animations limited to `transform` and `opacity`.
- CDN with long-lived immutable asset caching.

## Security & Privacy
- HTTPS everywhere, HSTS, sane CSP.
- Donations through a PCI-compliant gateway (Razorpay/Cashfree/PayU are the usual Indian options); no card data in your own systems or logs.
- Donor identity never published; access to donor records restricted and audited.
- Privacy-conscious, cookie-light analytics; consent management for anything non-essential; collect only what is needed.
- Spam protection on all public forms; server-side validation always.

## Assets
- `logo.png` — the trust's emblem, supplied by the organisation. Already processed for this design: the source screenshot's card border was cropped (4.5% inset) and the near-white background knocked out to transparency, so it sits cleanly on both ivory and charcoal. **Request a vector (SVG/AI) original from the trust** — the emblem carries fine Devanagari lettering around the ring that will not hold up at small sizes or in print from a raster file. Also request a simplified mark for favicon and small-scale use; the full ring is illegible below ~48px.
- `uploads/pasted-1787584183164-0.png` — the original unprocessed emblem screenshot, for reference.
- Photography: none supplied. All seven image slots need real photographs.
- Icons: the five pillar symbols in the prototype are placeholder geometry built from CSS shapes. Commission a proper single-weight line set; keep one accent per glyph, no illustration, no emoji.

## Files
- `Panch Pran Vikas Trust.dc.html` — desktop homepage, now including the working mega-menu (hover a nav item with a caret).
- `PPVT Mobile.dc.html` — three live 390×844 frames: mobile homepage (sticky header + persistent donate bar), navigation drawer with "Our Work" expanded, and the same mobile layout in the English locale as a string-length check.
- `PPVT Donate.dc.html` — the full donation flow as a working prototype: amount → details → confirm → thank-you, with validation, monthly/one-time, directed giving, and a sticky honesty rail.
- `PPVT Impact.dc.html` — impact page with programme distribution, yearly progress, participation split, geographic ranking, the empty-state pattern for unpopulated charts, and a "how we measure" method block.
- `PPVT Pillar.dc.html` — the templated pillar page, one design serving all five commitments. Switch which one it renders with the `pillar` prop (`education` | `self` | `environment` | `women` | `health`); each carries its own lead copy, "why this pledge" argument, activity list, story, and measurement method. Verified-figure row renders em-dashes rather than invented numbers.
- `PPVT Transparency.dc.html` — transparency centre: disclosure register with status per document, registration table, governance placeholders, use-of-funds (deliberately empty bars), grievance channel, donor privacy, corrections policy.
- Design reference detail below applies to the homepage; Self-contained apart from the fonts (Google Fonts), the emblem, and `image-slot.js`. Open it in a browser at ≥1440px wide to see the intended composition.
- `image-slot.js` — the drag-and-drop photo placeholder used by the prototype. **Design tooling only; do not port it.** Replace with the target stack's image component.
- `logo.png`, `uploads/pasted-1787584183164-0.png` — see Assets.

## Accessibility corrections applied after audit
Four palette values failed WCAG AA as small text and were darkened. Use these in production:
- `#6F927F` → **`#4F7462`** for English pillar labels, locations, and any small text (the original stays for dots, borders, and fills)
- `#8A9490` → **`#667370`** for all monospace annotations
- `#D97745` → **`#A9552B`** for eyebrow text on ivory; the original terracotta is kept on dark green, where it passes
- `#8A5A34` → **`#7A4E2B`** for text on sand

Also fixed: visible `:focus-visible` rings on every page, the mega-menu opens on keyboard focus as well as hover, the brand lockup no longer wraps below 1200px, and the header wraps rather than pushing the donate CTA off-screen.

## Not yet designed
Ranked by what unblocks the most work:
1. Full English locale on desktop (mobile is drawn and checked; desktop is not)
2. Tablet breakpoint (768–1279px) — specced in words above, not drawn. The prototypes use inline styles and carry no media queries, so tablet behaviour must be implemented from the spec rather than read off the files
4. Story of Change detail, Project detail
6. About / Leadership / Governance
7. Volunteer, Partner With Us, Contact
8. 404


---

## Post-audit remediation — read this first

A full v1 audit was run against these designs and thirty findings were recorded. Twenty-six were fixed in the design files; the audit report (`PPVT V1 Audit.dc.html`, at the project root) carries the complete record, including what was wrong before the fix.

**The design files now live at the project root, not in this folder.** Duplicate copies previously kept here were deleted — they had drifted out of date. Build from the root files:

| File | What it is |
|---|---|
| `Panch Pran Vikas Trust.dc.html` | Desktop homepage, Hindi-led |
| `PPVT Homepage EN.dc.html` | Desktop homepage, English locale |
| `PPVT Mobile.dc.html` | Seven 390×844 frames: homepage, drawer, English homepage, donate amount, donate details, transparency, commitment page |
| `PPVT Pillar.dc.html` | Commitment template — resolves all five from `?pillar=` |
| `PPVT Donate.dc.html` | Four-step donate flow; accepts `?amount=` and `?freq=` |
| `PPVT Impact.dc.html` | Impact reporting, all charts in empty state |
| `PPVT Transparency.dc.html` | Disclosure register |
| `PPVT Legal.dc.html` | Five policy documents, each with scope and outstanding items |
| `PPVT-Footer.dc.html` | Shared footer, imported by the subpages |

### Changes that alter the build spec

**Responsive behaviour replaced fixed grids.** Every `repeat(n,1fr)` became `repeat(auto-fit,minmax(<track>,1fr))`, and every two-column section collapses at roughly 640px via `minmax(min(100%,320px),1fr)`. Page gutters are `clamp(20px,5vw,56px)`. **There are no media queries and none are needed** — do not add breakpoints when porting. Tablet, 768–1279px, is covered by the same rules.

**The navigation was cut from 26 items to 7.** Every destination in it now exists. Do not restore the mega-menu until the pages behind it are built; the remaining "Our Work" menu is a disclosure — button trigger, `aria-expanded`, Escape to close, and it must not open on focus alone.

**Devanagari headings run at `line-height: 1.34` and `letter-spacing: 0`.** Latin keeps its tighter metrics. Do not apply one set to both scripts — this is the single type decision that most affects perceived quality.

**The focus ring is two-tone:** `outline: 2px solid #174A3A` plus `box-shadow: 0 0 0 4px #FAF8F3`, so it reads on ivory and on dark green. Keep both halves.

**Language must be declared.** `lang` on the document per locale, and `lang="hi"` on every Devanagari run. This is a WCAG 3.1 requirement, not a nicety — Hindi carries the primary message.

**Donate flow contract.** Custom amount filters to digits on entry, minimum ₹100, and never falls back silently to a preset. The flow reads `?amount=` and `?freq=` so the homepage tiles carry the donor's choice in. The confirmation screen states plainly that no payment was taken — remove that notice only when a real gateway is connected.

**No figure on any page is real.** Every metric is an em-dash and every chart is an empty state carrying its intended source. Populate them only from a verified report, with the period recorded. Never populate a chart to make a page look finished.

### Outstanding, by owner

**The trust must supply:** approved text for privacy, terms, refunds and cancellation, cookies and accessibility · registration number and date, PAN, registered office, phone, email · trust deed, registration certificate, audited accounts, exemption certificates · trustee names, roles, biographies, photographs · the six policies · verified figures with periods · the grievance channel and its response window · seven photographs with recorded consent · three interview-based stories.

**Build owns:** page titles, descriptions and NGO schema (the `og:image` and JSON-LD slots are marked with comments in each file) · subset self-hosted woff2, three weights, one mono weight, hero preload, and a stated page-weight budget — the audience is largely on mid-tier Android over mobile data · payment gateway and receipting · form accessibility wiring · the image pipeline · wiring the disclosure counter to the document library · the cookie table must match what the consent bar actually sets.

**Design still owes:** detail shells for stories of change, projects and annual reports · about, leadership and governance pages · a 404 · one review pass on a real mid-tier Android · a simplified vector emblem for small sizes and favicons, which needs the original artwork from whoever drew the logo.

### The one rule to preserve

The disclosure discipline is this design's strongest idea. No certificate, rating, award, partner logo or figure appears until the document behind it exists, and empty slots keep their place in the layout rather than quietly disappearing. It is a more persuasive trust signal for an unknown trust than any number would be. If a stakeholder asks for a number to fill a gap, the answer is the em-dash.
